How it works?
All heart containers are instantiated at start, and unused heart containers are disabled until being used.
The property fillAMount of UI Images are used to fill the hearts. 1 heart equals to 1 health.

Why using floats?
Well, this assets was originally part of a game of mine, where the player would have a health between 3 and 20. Monsters
would deal about 1 damage, and later in the game the player could get armors (reducing damage by 25% or 50%, multiplying
the damage by 0.75f or 0.5f, respectively).